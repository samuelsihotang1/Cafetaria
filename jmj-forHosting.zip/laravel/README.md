![web-view](./Homepage.png)

# Samuel C. A. Sihotang - Portofolio
## Cafetaria
A website that can assist cafeteria operators in determining the ratings of the food menus they offer.
<br>
<a href="https://kantin.samuelsihotang.my.id/">Cafetaria</a>

### Made with
- HTML
- CSS
- PHP
- Laravel
- JavaScript
- Alpine JS
- Livewire
- Tailwind

### Give a star please
